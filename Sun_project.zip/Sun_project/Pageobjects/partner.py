import time



from Utilities import XLUtils
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.remote import switch_to
from selenium.webdriver.support.select import Select
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

class ParnterPage():

    txt_email_xpath = "//input[@placeholder='Enter Email ID']"
    txt_password_xpath = "//input[@placeholder='Enter Password ']"
    btn_login_xpath = "//button[normalize-space()='LOGIN']"
    txt_parnter_xpath = "//i[@class='feather icon-partners']"
    txt_parnter_search_xpath = "//input[@type='search']"
    txt_parnter_piagg_xpath = "//a[normalize-space()='SUNMP00000017']"
    txt_partner_pia_xpath="//a[normalize-space()='SUNMP00000153']"
    add_new_vehicle_btn_xpath = "//button[normalize-space()='Add New Vehicle']"
    add_new_vehicle_btn11_xpath = "//a[@id='ngb-tab-57']"
    cate_dropdown_form ="//select[@placeholder='Select Category']"
    vech_dropdown_form = "//select[@placeholder='Select Vehicletype']"
    vin_form ="//div[@class='form-group ng-star-inserted']//input[@id='VIN']"
    master_doc_form = "//input[@role='combobox']"
    reg_num_form = "//input[@id='RegistrationNumber']"
    drive_train_num_form = "//input[@id='engineNumber']"
    vehicle_manu_dropdown = "//select[@placeholder='Select Manufacturer']"
    manufacture_date ="//input[@placeholder='yyyy-mm-dd']"
    mon_date="//select[@title='Select month']"
    yer_date="//select[@title='Select year']"
    date_date="//div[@class='ngb-dp-months']//div"
    model_form="//input[@id='Model']"
    state_dropdown="//select[@placeholder='Select State']"
    zone_dropdown="//select[@placeholder='Select Zone']"
    add_button_form="//span[normalize-space()='Add']"
    master_doc_dropdown="//*[@id='a2a8a73a8481']"
    search_vec="//input[@id='VIN']"
    search_vec_click="//span[@class='feather icon-search']"
    new_vechlink = "//span[@class='fas fa-link']"
    new_vech_cusom_name="//input[@role='combobox']"
    new_vech_submit_btn="//span[normalize-space()='SUBMIT']"
    sample_click="//label[@for='CustomerId']"
    side_click="//span[@class='ng-arrow']"
    side_click1="//span[@class='ng-arrow']"
    customer_name="//ng-select[@placeholder='Select ']//input[@role='combobox']"
    bussiness_type="//ng-select[@placeholder='Select bussines type']//input[@role='combobox']"
    deployment_type="//ng-select[@placeholder='Select deployment type']//input[@role='combobox']"
    customer_sub_btn="//span[normalize-space()='SUBMIT']"
    arrow1="(//span[@class='ng-arrow'])[1]"
    arrow2="(//span[@class='ng-arrow-wrapper'])[2]"
    arrow3="(//span[@class='ng-arrow-wrapper'])[3]"
    add_partner_btn="//button[normalize-space()='Add Partner']"
    partner_type_dropdown="//select[@placeholder='Select Type']"
    organization_name_field="//input[@placeholder='Enter organization name']"
    brand_drop_down="//select[@placeholder='Select Brand']"
    first_name_field="//input[@placeholder='Enter first name']"
    middle_name_field="//input[@placeholder='Enter middle name']"
    last_name_filed="//input[@placeholder='Enter last name']"
    mobile_num_field="//input[@placeholder='Enter Mobile Number']"
    identity_type_field_dropdown="//select[@placeholder='Select Identity']"
    identity_number_field="//input[@placeholder='Enter Identity Number']"
    choose_file="//input[@formcontrolname='identityFile']"
    email_id_filed="//input[@placeholder='Enter email id']"
    pan_field="//input[@placeholder='Enter pan ']"
    pan_choose_file="//input[@formcontrolname='panfile']"
    gst_filed="//input[@placeholder='Enter GST ']"
    gst_choose_file="//input[@formcontrolname='gstfile']"
    address_filed="//input[@placeholder='Enter Address']"
    city_filed="//input[@placeholder='Enter City']"
    pincode_filed="//input[@placeholder='Enter Pincode']"
    state_dropdown_add="//select[@placeholder='Select State']"
    country_filed="//input[@placeholder='Enter Country']"
    address_proof_choose_file="//input[@id='addressfile']"
    bank_name_filed="//input[@placeholder='Enter Bank Name']"
    benificiary_name_filed="//input[@placeholder='Enter Benificiary Name']"
    account_name_filed="//input[@placeholder='Enter Account number']"
    IFSC_code_filed="//input[@placeholder='Enter IFSC code']"
    cancelled_check_choose_file="//input[@formcontrolname='bankdocfile']"
    sm_mobile_app_side_click="//span[@class='ng-star-inserted']"
    select_all_checkbox="//div[normalize-space()='Select All']"
    add_partner_submit_btn="//button[normalize-space()='Submit']"
    popUp_ok_pan="//button[normalize-space()='OK']"
    sideclick_sm_mobiles="//span[@class='dropdown-up']"
    sm_esv_app_select="//div[normalize-space()='SM ESV App']"
    certificate_of_incopo_file_upload="//input[@formcontrolname='incorporationfile']"
    otp_xpath="/html/body/div[2]/div/div[3]/button[1]"






    file = "C:\\Users\\ranganath.hd\\Sun1_project\\Sun_project\\Testdata\\test_data.xlsx"
    Category_dropdown = XLUtils.readData(file, "add_vech_form", 2, 1)
    VehicleType_dropdown = XLUtils.readData(file, "add_vech_form", 2, 2)
    vin = XLUtils.readData(file, "add_vech_form", 2, 3)
    materdocid= XLUtils.readData(file, "add_vech_form", 2, 4)
    Registration_Number= XLUtils.readData(file, "add_vech_form", 2, 5)
    Drive_train=XLUtils.readData(file, "add_vech_form", 2, 6)
    Vehicle_Manufacturer_dropdown=XLUtils.readData(file, "add_vech_form", 2, 7)
    Manufacturing_Date_year=XLUtils.readData(file, "add_vech_form", 2, 8)
    model = XLUtils.readData(file, "add_vech_form", 2, 9)
    state_dropdown_=XLUtils.readData(file, "add_vech_form", 2, 10)
    zone_dropdown_=XLUtils.readData(file, "add_vech_form", 2, 11)
    dealer_name_ = XLUtils.readData(file, "add_vech_form", 2, 12)
    customer_name_ = XLUtils.readData(file, "add_vech_form", 2, 13)
    bussiness_type_ = XLUtils.readData(file, "add_vech_form", 2, 14)
    deployment_type_ = XLUtils.readData(file, "add_vech_form", 2, 15)
    vin1 = XLUtils.readData(file, "add_vech_form", 3, 3)

# ADD PARTNER DATA READ FROM EXCEL

    PartnerType = XLUtils.readData(file, "add_partner", 2, 1)
    PartnerTypemass = XLUtils.readData(file, "add_partner", 3, 1)
    OrganizationName = XLUtils.readData(file, "add_partner", 2, 2)
    Brand = XLUtils.readData(file, "add_partner", 2, 3)
    Brandmass = XLUtils.readData(file, "add_partner", 3, 3)


    FirstName = XLUtils.readData(file, "add_partner", 2, 4)
    MiddleName = XLUtils.readData(file, "add_partner", 2, 5)
    LastName = XLUtils.readData(file, "add_partner", 2, 6)
    MobileNumber = XLUtils.readData(file, "add_partner", 2, 7)
    IdentityType= XLUtils.readData(file, "add_partner", 2, 8)
    Identitynumber = XLUtils.readData(file, "add_partner", 2, 9)
    EmailId = XLUtils.readData(file, "add_partner", 2, 10)
    PAN = XLUtils.readData(file, "add_partner", 2, 11)
    GSTIN = XLUtils.readData(file, "add_partner", 2, 12)
    Address = XLUtils.readData(file, "add_partner", 2, 13)
    City = XLUtils.readData(file, "add_partner", 2, 14)
    Pincode = XLUtils.readData(file, "add_partner", 2, 15)
    State = XLUtils.readData(file, "add_partner", 2, 16)
    Country = XLUtils.readData(file, "add_partner", 2, 17)
    BankName = XLUtils.readData(file, "add_partner", 2, 18)
    BenificiaryName = XLUtils.readData(file, "add_partner", 2, 19)
    AccountNumber = XLUtils.readData(file, "add_partner", 2, 20)
    IFSCCode = XLUtils.readData(file, "add_partner", 2, 21)
    DOCLOCATION = XLUtils.readData(file, "add_partner", 2, 22)
    # BankName = XLUtils.readData(file, "add_partner", 2, 17)




    def __init__(self, driver):
        self.driver = driver
        global mywait
        mywait = WebDriverWait(self.driver, 10, poll_frequency=2)



    def setEmail(self, email):
        self.driver.find_element(By.XPATH,self.txt_email_xpath).send_keys(email)

    def setPassword(self, pwd):
        self.driver.find_element(By.XPATH,self.txt_password_xpath).send_keys(pwd)

    def clickLogin(self):
        # searchlink = mywait.until(EC.presence_of_element_located((By.XPATH, "//h3[text()='Selenium']")))

        WebDriverWait(self.driver, 20).until(EC.element_to_be_clickable((By.XPATH, self.btn_login_xpath))).click()


    def partner(self):
        self.driver.find_element(By.XPATH, self.txt_parnter_xpath).click()

    def partnersearch(self):
        act = ActionChains(self.driver)
        sea = self.driver.find_element(By.XPATH, self.txt_parnter_search_xpath)
        act.move_to_element(sea).click().perform()
        self.driver.find_element(By.XPATH, self.txt_parnter_piagg_xpath).click()

        # time.sleep(5)

    def addnewvehicle(self):

        act = ActionChains(self.driver)
        time.sleep(5)
        addvec1 =mywait.until(EC.presence_of_element_located((By.XPATH, self.add_new_vehicle_btn_xpath)))
        # addvec1 =WebDriverWait(self.driver, 20).until(EC.element_to_be_clickable((By.XPATH, self.add_new_vehicle_btn_xpath)))
        # addvec1 = WebDriverWait(self.driver, 10).until(EC.presence_of_element_located((By.XPATH, self.add_new_vehicle_btn_xpath)))
        # addvec1 = self.driver.find_element(By.XPATH, self.add_new_vehicle_btn_xpath)
        act.move_to_element(addvec1).click().perform()
        time.sleep(5)
        # dr=Select(WebDriverWait(self.driver, 20).until(EC.element_to_be_clickable((By.XPATH, self.cate_dropdown_form))))
        dr = Select(self.driver.find_element(By.XPATH, self.cate_dropdown_form))
        dr.select_by_visible_text(self.Category_dropdown)
        dr1 = Select(self.driver.find_element(By.XPATH, self.vech_dropdown_form))
        dr1.select_by_visible_text(self.VehicleType_dropdown)
        self.driver.find_element(By.XPATH, self.vin_form).send_keys(self.vin)

        # dr3 = Select(self.driver.find_element(By.XPATH, self.master_doc_form))
        # dr3.select_by_visible_text("INSMOMAD0104G280210E")
        sideclick1 = self.driver.find_element(By.XPATH, self.side_click)
        act.move_to_element(sideclick1).click().perform()
        self.driver.find_element(By.XPATH, self.master_doc_form).send_keys(self.materdocid)
        self.driver.find_element(By.XPATH, self.master_doc_form).send_keys(Keys.ENTER)
        # mass=self.driver.find_element(By.XPATH, self.master_doc_dropdown)
        # act.move_to_element(mass).click().perform()
        self.driver.find_element(By.XPATH, self.reg_num_form).send_keys(self.Registration_Number)
        self.driver.find_element(By.XPATH, self.drive_train_num_form).send_keys(self.Drive_train)
        dr2 = Select(self.driver.find_element(By.XPATH, self.vehicle_manu_dropdown))
        dr2.select_by_visible_text(self.Vehicle_Manufacturer_dropdown)

        self.driver.find_element(By.XPATH,self.manufacture_date).send_keys(self.Manufacturing_Date_year)
        # mon = Select(self.driver.find_element(By.XPATH,self.mon_date))
        # mon.select_by_visible_text(self.Manufacturing_Date_month)
        #
        # yer = Select(self.driver.find_element(By.XPATH,self.yer_date))
        # yer.select_by_visible_text("2018")
        # time.sleep(3)
        # dates = self.driver.find_elements(By.XPATH,self.date_date)
        # for ele in dates:
        #     if ele.text == self.Manufacturing_Date_day.text:
        #         ele.click()
        #         break
        time.sleep(3)
        self.driver.find_element(By.XPATH, self.model_form).send_keys(self.model)
        dr3 = Select(self.driver.find_element(By.XPATH, self.state_dropdown))
        dr3.select_by_visible_text(self.state_dropdown_)
        dr4 = Select(self.driver.find_element(By.XPATH, self.zone_dropdown))
        time.sleep(3)
        dr4.select_by_visible_text(self.zone_dropdown_)
        self.driver.find_element(By.XPATH, self.add_button_form).click()
        time.sleep(10)

    def addnewvehicleneg(self):

        act = ActionChains(self.driver)
        time.sleep(5)
        addvec1 =mywait.until(EC.presence_of_element_located((By.XPATH, self.add_new_vehicle_btn_xpath)))
        # addvec1 =WebDriverWait(self.driver, 20).until(EC.element_to_be_clickable((By.XPATH, self.add_new_vehicle_btn_xpath)))
        # addvec1 = WebDriverWait(self.driver, 10).until(EC.presence_of_element_located((By.XPATH, self.add_new_vehicle_btn_xpath)))
        # addvec1 = self.driver.find_element(By.XPATH, self.add_new_vehicle_btn_xpath)
        act.move_to_element(addvec1).click().perform()
        time.sleep(5)
        # dr=Select(WebDriverWait(self.driver, 20).until(EC.element_to_be_clickable((By.XPATH, self.cate_dropdown_form))))
        dr = Select(self.driver.find_element(By.XPATH, self.cate_dropdown_form))
        dr.select_by_visible_text(self.Category_dropdown)
        dr1 = Select(self.driver.find_element(By.XPATH, self.vech_dropdown_form))
        dr1.select_by_visible_text(self.VehicleType_dropdown)
        self.driver.find_element(By.XPATH, self.vin_form).send_keys(self.vin1)

        # dr3 = Select(self.driver.find_element(By.XPATH, self.master_doc_form))
        # dr3.select_by_visible_text("INSMOMAD0104G280210E")
        sideclick1 = self.driver.find_element(By.XPATH, self.side_click)
        act.move_to_element(sideclick1).click().perform()
        self.driver.find_element(By.XPATH, self.master_doc_form).send_keys(self.materdocid)
        self.driver.find_element(By.XPATH, self.master_doc_form).send_keys(Keys.ENTER)
        # mass=self.driver.find_element(By.XPATH, self.master_doc_dropdown)
        # act.move_to_element(mass).click().perform()
        self.driver.find_element(By.XPATH, self.reg_num_form).send_keys(self.Registration_Number)
        self.driver.find_element(By.XPATH, self.drive_train_num_form).send_keys(self.Drive_train)
        dr2 = Select(self.driver.find_element(By.XPATH, self.vehicle_manu_dropdown))
        dr2.select_by_visible_text(self.Vehicle_Manufacturer_dropdown)

        self.driver.find_element(By.XPATH,self.manufacture_date).send_keys(self.Manufacturing_Date_year)

        time.sleep(3)
        self.driver.find_element(By.XPATH, self.model_form).send_keys(self.model)
        dr3 = Select(self.driver.find_element(By.XPATH, self.state_dropdown))
        dr3.select_by_visible_text(self.state_dropdown_)
        dr4 = Select(self.driver.find_element(By.XPATH, self.zone_dropdown))
        time.sleep(3)
        dr4.select_by_visible_text(self.zone_dropdown_)
        self.driver.find_element(By.XPATH, self.add_button_form).click()
        time.sleep(10)




    def searchvech(self):
        self.driver.find_element(By.XPATH, self.search_vec).send_keys(self.vin)
        self.driver.find_element(By.XPATH, self.search_vec_click).click()

    def linkvech(self):
        act = ActionChains(self.driver)
        time.sleep(2)
        self.driver.find_element(By.XPATH, self.new_vechlink).click()
        sideclick=self.driver.find_element(By.XPATH, self.side_click)
        act.move_to_element(sideclick).click().perform()
        self.driver.find_element(By.XPATH, self.new_vech_cusom_name).send_keys(self.dealer_name_)
        self.driver.find_element(By.XPATH, self.new_vech_cusom_name).send_keys(Keys.ENTER)

        self.driver.find_element(By.XPATH, self.new_vech_submit_btn).click()
        time.sleep(3)

    def partnersearch1(self):
        self.driver.implicitly_wait(20)
        act = ActionChains(self.driver)
        sea = self.driver.find_element(By.XPATH, self.txt_parnter_search_xpath)
        act.move_to_element(sea).click().perform()
        self.driver.find_element(By.XPATH, self.txt_partner_pia_xpath).click()
        self.driver.find_element(By.XPATH, self.search_vec).send_keys(self.vin)
        time.sleep(5)
        self.driver.find_element(By.XPATH, self.search_vec_click).click()
        time.sleep(3)
        self.driver.find_element(By.XPATH, self.new_vechlink).click()
        time.sleep(2)
        sideclick3 = self.driver.find_element(By.XPATH, self.arrow1)
        act.move_to_element(sideclick3).click().perform()
        self.driver.find_element(By.XPATH, self.customer_name).send_keys(self.customer_name_)
        self.driver.find_element(By.XPATH, self.customer_name).send_keys(Keys.ENTER)
        sideclick4 = self.driver.find_element(By.XPATH, self.arrow2)
        act.move_to_element(sideclick4).click().perform()
        self.driver.find_element(By.XPATH, self.bussiness_type).send_keys(self.bussiness_type_)
        self.driver.find_element(By.XPATH, self.bussiness_type).send_keys(Keys.ENTER)
        sideclick5 = self.driver.find_element(By.XPATH, self.arrow3)
        act.move_to_element(sideclick5).click().perform()
        self.driver.find_element(By.XPATH, self.deployment_type).send_keys(self.deployment_type_)
        self.driver.find_element(By.XPATH, self.deployment_type).send_keys(Keys.ENTER)
        # self.driver.find_element(By.XPATH, self.customer_sub_btn).click()
        time.sleep(15)

    def addoempartner(self):
        self.driver.implicitly_wait(20)
        act = ActionChains(self.driver)
        time.sleep(3)
        sea = self.driver.find_element(By.XPATH, self.txt_parnter_search_xpath)
        act.move_to_element(sea).click().perform()
        self.driver.find_element(By.XPATH, self.add_partner_btn).click()

        adddr = Select(self.driver.find_element(By.XPATH, self.partner_type_dropdown))
        adddr.select_by_visible_text(self.PartnerType)
        self.driver.find_element(By.XPATH, self.organization_name_field).send_keys(self.OrganizationName)
        adddr1 = Select(self.driver.find_element(By.XPATH, self.brand_drop_down))
        adddr1.select_by_visible_text(self.Brand)
        self.driver.find_element(By.XPATH, self.first_name_field).send_keys(self.FirstName)
        self.driver.find_element(By.XPATH, self.middle_name_field).send_keys(self.MiddleName)
        self.driver.find_element(By.XPATH, self.last_name_filed).send_keys(self.LastName)
        self.driver.find_element(By.XPATH, self.mobile_num_field).send_keys(self.MobileNumber)
        time.sleep(3)
        # self.driver.find_element(By.XPATH, self.identity_type_field_dropdown).click()
        # sea3 = self.driver.find_element(By.XPATH, self.popUp_ok_mobile)
        # act.move_to_element(sea3).click().perform()
        # time.sleep(30)
        adddr2 = Select(self.driver.find_element(By.XPATH, self.identity_type_field_dropdown))
        adddr2.select_by_visible_text(self.IdentityType)
        time.sleep(2)
        self.driver.find_element(By.XPATH, self.identity_number_field).send_keys(self.Identitynumber)
        time.sleep(2)
        self.driver.find_element(By.XPATH, self.email_id_filed).send_keys(self.EmailId)
        time.sleep(2)
        self.driver.find_element(By.XPATH, self.choose_file).send_keys(self.DOCLOCATION)
        time.sleep(2)
        self.driver.find_element(By.XPATH, self.pan_field).send_keys(self.PAN)
        time.sleep(2)

        self.driver.find_element(By.XPATH, self.pan_choose_file).send_keys(self.DOCLOCATION)
        time.sleep(3)
        sea3 = self.driver.find_element(By.XPATH, self.popUp_ok_pan)
        act.move_to_element(sea3).click().perform()
        sea4 = self.driver.find_element(By.XPATH, self.popUp_ok_pan)
        act.move_to_element(sea4).click().perform()
        self.driver.find_element(By.XPATH, self.gst_filed).send_keys(self.GSTIN)
        self.driver.find_element(By.XPATH, self.gst_choose_file).send_keys(self.DOCLOCATION)
        self.driver.find_element(By.XPATH, self.address_filed).send_keys(self.Address)
        self.driver.find_element(By.XPATH, self.city_filed).send_keys(self.City)
        self.driver.find_element(By.XPATH, self.pincode_filed).send_keys(self.Pincode)
        adddr3 = Select(self.driver.find_element(By.XPATH, self.state_dropdown_add))
        adddr3.select_by_visible_text(self.State)
        self.driver.find_element(By.XPATH, self.country_filed).send_keys(self.Country)
        self.driver.find_element(By.XPATH, self.address_proof_choose_file).send_keys(self.DOCLOCATION)
        self.driver.find_element(By.XPATH, self.bank_name_filed).send_keys(self.BankName)
        self.driver.find_element(By.XPATH, self.benificiary_name_filed).send_keys(self.BenificiaryName)
        self.driver.find_element(By.XPATH, self.account_name_filed).send_keys(self.AccountNumber)
        self.driver.find_element(By.XPATH, self.IFSC_code_filed).send_keys(self.IFSCCode)
        self.driver.find_element(By.XPATH, self.cancelled_check_choose_file).send_keys(self.DOCLOCATION)
        # sea23=self.driver.find_elements(By.XPATH, self.sm_mobile_app_side_click)
        # act.move_to_element(sea23).click().perform()

        # for list in sea23:
        #     # print(list.text)
        #     # if list.text == "Select All":
        #     act.move_to_element(list).click().perform()
        #     break
        # time.sleep(10)

        element =self.driver.find_element(By.CSS_SELECTOR, ".dropdown-down")
        self.driver.execute_script("arguments[0].click();", element)
        element1 = self.driver.find_element(By.CSS_SELECTOR, "ul[class='item1'] div")
        self.driver.execute_script("arguments[0].click();", element1)
        element2 = self.driver.find_element(By.CSS_SELECTOR, ".btn.btn-primary.mr-1")
        self.driver.execute_script("arguments[0].click();", element2)

        # sea5 = self.driver.find_element(By.XPATH, "(//span[@class='ng-star-inserted'])[1]")
        # act.move_to_element(sea5).click().perform()
        # lists = self.driver.find_elements(By.XPATH, "//ul[@class='item2']//li")
        # for list in lists:
        #     if list.text == "Select All":
        #         list.click()
        #     time.sleep(2)
        #     break


        time.sleep(20)

        # sea6 = self.driver.find_element(By.XPATH, self.sm_esv_app_select)
        # act.move_to_element(sea6).click().perform()
        # self.driver.find_element(By.XPATH, self.sm_mobile_app_side_click).click()
        # sea44=self.driver.find_element(By.XPATH, self.add_partner_submit_btn)
        # act.move_to_element(sea44).click().perform()
        # time.sleep(15)

    def addmassfleetpartner(self):
        self.driver.implicitly_wait(20)
        act = ActionChains(self.driver)
        time.sleep(3)
        sea = self.driver.find_element(By.XPATH, self.txt_parnter_search_xpath)
        act.move_to_element(sea).click().perform()
        self.driver.find_element(By.XPATH, self.add_partner_btn).click()

        adddr = Select(self.driver.find_element(By.XPATH, self.partner_type_dropdown))
        adddr.select_by_visible_text(self.PartnerTypemass)
        self.driver.find_element(By.XPATH, self.organization_name_field).send_keys(self.OrganizationName)
        adddr1 = Select(self.driver.find_element(By.XPATH, self.brand_drop_down))
        adddr1.select_by_visible_text(self.Brandmass)
        self.driver.find_element(By.XPATH, self.first_name_field).send_keys(self.FirstName)
        self.driver.find_element(By.XPATH, self.middle_name_field).send_keys(self.MiddleName)
        self.driver.find_element(By.XPATH, self.last_name_filed).send_keys(self.LastName)
        self.driver.find_element(By.XPATH, self.mobile_num_field).send_keys(self.MobileNumber)
        time.sleep(3)
        # self.driver.find_element(By.XPATH, self.identity_type_field_dropdown).click()
        # sea3 = self.driver.find_element(By.XPATH, self.popUp_ok_mobile)
        # act.move_to_element(sea3).click().perform()
        # time.sleep(30)
        adddr2 = Select(self.driver.find_element(By.XPATH, self.identity_type_field_dropdown))
        adddr2.select_by_visible_text(self.IdentityType)
        time.sleep(2)
        self.driver.find_element(By.XPATH, self.identity_number_field).send_keys(self.Identitynumber)
        time.sleep(2)
        self.driver.find_element(By.XPATH, self.email_id_filed).send_keys(self.EmailId)
        time.sleep(2)
        self.driver.find_element(By.XPATH, self.choose_file).send_keys(self.DOCLOCATION)
        time.sleep(2)
        self.driver.find_element(By.XPATH, self.pan_field).send_keys(self.PAN)
        time.sleep(2)

        self.driver.find_element(By.XPATH, self.pan_choose_file).send_keys(self.DOCLOCATION)
        time.sleep(3)
        sea3 = self.driver.find_element(By.XPATH, self.popUp_ok_pan)
        act.move_to_element(sea3).click().perform()
        sea4 = self.driver.find_element(By.XPATH, self.popUp_ok_pan)
        act.move_to_element(sea4).click().perform()
        self.driver.find_element(By.XPATH, self.gst_filed).send_keys(self.GSTIN)
        self.driver.find_element(By.XPATH, self.gst_choose_file).send_keys(self.DOCLOCATION)
        self.driver.find_element(By.XPATH, self.certificate_of_incopo_file_upload).send_keys(self.DOCLOCATION)

        self.driver.find_element(By.XPATH, self.address_filed).send_keys(self.Address)
        self.driver.find_element(By.XPATH, self.city_filed).send_keys(self.City)
        self.driver.find_element(By.XPATH, self.pincode_filed).send_keys(self.Pincode)
        adddr3 = Select(self.driver.find_element(By.XPATH, self.state_dropdown_add))
        adddr3.select_by_visible_text(self.State)
        # self.driver.find_element(By.XPATH, self.country_filed).send_keys(self.Country)
        self.driver.find_element(By.XPATH, self.address_proof_choose_file).send_keys(self.DOCLOCATION)
        self.driver.find_element(By.XPATH, self.bank_name_filed).send_keys(self.BankName)
        self.driver.find_element(By.XPATH, self.benificiary_name_filed).send_keys(self.BenificiaryName)
        self.driver.find_element(By.XPATH, self.account_name_filed).send_keys(self.AccountNumber)
        self.driver.find_element(By.XPATH, self.IFSC_code_filed).send_keys(self.IFSCCode)
        self.driver.find_element(By.XPATH, self.cancelled_check_choose_file).send_keys(self.DOCLOCATION)
        # sea23=self.driver.find_elements(By.XPATH, self.sm_mobile_app_side_click)
        # act.move_to_element(sea23).click().perform()

        # for list in sea23:
        #     # print(list.text)
        #     # if list.text == "Select All":
        #     act.move_to_element(list).click().perform()
        #     break
        # time.sleep(10)

        element =self.driver.find_element(By.CSS_SELECTOR, ".dropdown-down")
        self.driver.execute_script("arguments[0].click();", element)
        element1 = self.driver.find_element(By.CSS_SELECTOR, "ul[class='item1'] div")
        self.driver.execute_script("arguments[0].click();", element1)
        element2 = self.driver.find_element(By.CSS_SELECTOR, ".btn.btn-primary.mr-1")
        self.driver.execute_script("arguments[0].click();", element2)
        time.sleep(20)

    def addalldelar(self):
        self.driver.implicitly_wait(20)
        act = ActionChains(self.driver)
        time.sleep(3)
        sea = self.driver.find_element(By.XPATH, self.txt_parnter_search_xpath)
        act.move_to_element(sea).click().perform()
        for r in range(4,29) :
            file = "C:\\Users\\ranganath.hd\\Sun1_project\\Sun_project\\Testdata\\test_data.xlsx"
            AllPartnerType = XLUtils.readData(file, "add_partner",r, 1)
            self.driver.find_element(By.XPATH, self.add_partner_btn).click()

            adddr = Select(self.driver.find_element(By.XPATH, self.partner_type_dropdown))
            adddr.select_by_visible_text(AllPartnerType)
            self.driver.find_element(By.XPATH, self.organization_name_field).send_keys(self.OrganizationName)
            adddr1 = Select(self.driver.find_element(By.XPATH, self.brand_drop_down))
            adddr1.select_by_index(1)
            self.driver.find_element(By.XPATH, self.first_name_field).send_keys(self.FirstName)
            self.driver.find_element(By.XPATH, self.middle_name_field).send_keys(self.MiddleName)
            self.driver.find_element(By.XPATH, self.last_name_filed).send_keys(self.LastName)
            self.driver.find_element(By.XPATH, self.mobile_num_field).send_keys(self.MobileNumber)
            time.sleep(3)
            # self.driver.find_element(By.XPATH, self.identity_type_field_dropdown).click()
            # sea3 = self.driver.find_element(By.XPATH, self.popUp_ok_mobile)
            # act.move_to_element(sea3).click().perform()
            # time.sleep(30)
            adddr2 = Select(self.driver.find_element(By.XPATH, self.identity_type_field_dropdown))
            adddr2.select_by_visible_text(self.IdentityType)
            time.sleep(2)
            self.driver.find_element(By.XPATH, self.identity_number_field).send_keys(self.Identitynumber)
            time.sleep(2)
            self.driver.find_element(By.XPATH, self.email_id_filed).send_keys(self.EmailId)
            time.sleep(2)
            self.driver.find_element(By.XPATH, self.choose_file).send_keys(self.DOCLOCATION)
            time.sleep(2)
            self.driver.find_element(By.XPATH, self.pan_field).send_keys(self.PAN)
            time.sleep(2)

            self.driver.find_element(By.XPATH, self.pan_choose_file).send_keys(self.DOCLOCATION)
            time.sleep(3)
            sea3 = self.driver.find_element(By.XPATH, self.popUp_ok_pan)
            act.move_to_element(sea3).click().perform()
            sea4 = self.driver.find_element(By.XPATH, self.popUp_ok_pan)
            act.move_to_element(sea4).click().perform()
            self.driver.find_element(By.XPATH, self.gst_filed).send_keys(self.GSTIN)
            self.driver.find_element(By.XPATH, self.gst_choose_file).send_keys(self.DOCLOCATION)
            try:
                self.driver.find_element(By.XPATH, self.certificate_of_incopo_file_upload).send_keys(self.DOCLOCATION)
            except:
                None

            self.driver.find_element(By.XPATH, self.address_filed).send_keys(self.Address)
            self.driver.find_element(By.XPATH, self.city_filed).send_keys(self.City)
            self.driver.find_element(By.XPATH, self.pincode_filed).send_keys(self.Pincode)
            adddr3 = Select(self.driver.find_element(By.XPATH, self.state_dropdown_add))
            adddr3.select_by_visible_text(self.State)
            # self.driver.find_element(By.XPATH, self.country_filed).send_keys(self.Country)
            self.driver.find_element(By.XPATH, self.address_proof_choose_file).send_keys(self.DOCLOCATION)
            self.driver.find_element(By.XPATH, self.bank_name_filed).send_keys(self.BankName)
            self.driver.find_element(By.XPATH, self.benificiary_name_filed).send_keys(self.BenificiaryName)
            self.driver.find_element(By.XPATH, self.account_name_filed).send_keys(self.AccountNumber)
            self.driver.find_element(By.XPATH, self.IFSC_code_filed).send_keys(self.IFSCCode)
            self.driver.find_element(By.XPATH, self.cancelled_check_choose_file).send_keys(self.DOCLOCATION)
            # sea23=self.driver.find_elements(By.XPATH, self.sm_mobile_app_side_click)
            # act.move_to_element(sea23).click().perform()

            # for list in sea23:
            #     # print(list.text)
            #     # if list.text == "Select All":
            #     act.move_to_element(list).click().perform()
            #     break
            # time.sleep(10)

            element = self.driver.find_element(By.CSS_SELECTOR, ".dropdown-down")
            self.driver.execute_script("arguments[0].click();", element)
            element1 = self.driver.find_element(By.CSS_SELECTOR, "ul[class='item1'] div")
            self.driver.execute_script("arguments[0].click();", element1)
            element2 = self.driver.find_element(By.CSS_SELECTOR, ".btn.btn-primary.mr-1")
            self.driver.execute_script("arguments[0].click();", element2)
            time.sleep(2)
            self.driver.back()
            time.sleep(2)
            sea5 = self.driver.find_element(By.XPATH, self.otp_xpath)
            act.move_to_element(sea5).click().perform()
            time.sleep(2)
            self.driver.find_element(By.XPATH, self.txt_parnter_xpath).click()
            time.sleep(2)
            sea6 = self.driver.find_element(By.XPATH, self.txt_parnter_search_xpath)
            act.move_to_element(sea6).click().perform()
            time.sleep(2)

































