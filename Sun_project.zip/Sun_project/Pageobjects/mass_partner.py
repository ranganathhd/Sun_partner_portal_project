import time
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.remote import switch_to
from selenium.webdriver.support.select import Select
from selenium.webdriver.common.keys import Keys
from Utilities import XLUtils

class MassParnterPage():

    txt_email_xpath = "//input[@placeholder='Enter Email ID']"
    txt_password_xpath = "//input[@placeholder='Enter Password ']"
    btn_login_xpath = "//button[normalize-space()='LOGIN']"
    txt_parnter_xpath = "//i[@class='feather icon-partners']"
    txt_parnter_search_xpath = "//input[@type='search']"
    parnter_mass_oem_xpath = "//a[normalize-space()='SUNMP00000106']"
    add_new_vehicle_btn_xpath = "//button[normalize-space()='Add New Vehicle']"
    vech_dropdown_form = "//select[@placeholder='Select Vehicletype']"
    vin_form = "//div[@class='form-group ng-star-inserted']//input[@id='VIN']"
    cate_dropdown_form = "//select[@placeholder='Select Category']"
    master_doc_form = "//input[@role='combobox']"
    bp_num_form="//div[@class='ng-select-container']//input[@role='combobox']"
    reg_num_form = "//input[@id='RegistrationNumber']"
    drive_train_num_form = "//input[@id='engineNumber']"
    vehicle_manu_dropdown = "//select[@placeholder='Select Manufacturer']"
    manufacture_date = "//input[@placeholder='yyyy-mm-dd']"
    mon_date = "//select[@title='Select month']"
    yer_date = "//select[@title='Select year']"
    date_date = "//div[@class='ngb-dp-months']//div"
    side_click = "(//span[@class='ng-arrow'])[1]"
    side_click_1="(//span[@class='ng-arrow'])[2]"
    side_click_2="(//span[@class='ng-arrow'])[3]"
    state_dropdown = "//select[@placeholder='Select State']"
    zone_dropdown = "//select[@placeholder='Select Zone']"
    add_button_form = "//span[normalize-space()='Add']"
    search_vec = "//input[@id='VIN']"
    search_vec_click = "//span[@class='feather icon-search']"
    maas_fleet_new_vechlink = "//span[@class='fas fa-link']"
    maas_fleet_operator_form="//input[@role='combobox']"
    mass_fleet_operator_submit="//span[normalize-space()='SUBMIT']"
    finance_partner="//a[normalize-space()='SUNMP00000113']"
    vech_tab_xpath="(//a[normalize-space()='VEHICLES'])[1]"
    search_partner="//input[@type='search']"
    vech_tab_side_click="(//span[@class='ng-arrow'])[1]"
    payment_status ="//span[@class='fas fa-times-circle']"
    deposite_amount_form="//input[@id='depositAmount']"
    date_of_recpit_form="//input[@placeholder='yyyy-mm-dd']"
    deposite_amount_submit_btn="//span[@class='mat-button-wrapper']"
    mass_fleet_opeartor="//a[normalize-space()='SUNMP00000156']"
    Mass_choose_cust_form="(//input[@role='combobox'])[1]"
    choose_business_form="(//input[@role='combobox'])[2]"
    deployment_type_form="(//input[@role='combobox'])[3]"
    customer_submit_btn="//span[normalize-space()='SUBMIT']"

    file = "C:\\Users\\ranganath.hd\\Sun1_project\\Sun_project\\Testdata\\test_data.xlsx"
    Category_dropdown = XLUtils.readData(file, "mass_partner", 2, 1)
    VehicleType_dropdown = XLUtils.readData(file, "mass_partner", 2, 2)
    vin = XLUtils.readData(file, "mass_partner", 2, 3)
    materdocid = XLUtils.readData(file, "mass_partner", 2, 4)
    bpid = XLUtils.readData(file, "mass_partner", 2, 5)
    Registration_Number = XLUtils.readData(file, "mass_partner", 2, 6)
    Drive_train = XLUtils.readData(file, "mass_partner", 2, 7)
    Vehicle_Manufacturer_dropdown = XLUtils.readData(file, "mass_partner", 2, 8)
    Manufacturing_Date_year = XLUtils.readData(file, "mass_partner", 2, 9)
    model = XLUtils.readData(file, "mass_partner", 2, 10)
    state_dropdown_ = XLUtils.readData(file, "mass_partner", 2, 11)
    zone_dropdown_ = XLUtils.readData(file, "mass_partner", 2, 12)
    maas_fleet_operator_ = XLUtils.readData(file, "mass_partner", 2, 13)
    deposite_amount = XLUtils.readData(file, "mass_partner", 2, 14)
    amount_recepit = XLUtils.readData(file, "mass_partner", 2, 15)

    customer_name_ = XLUtils.readData(file, "mass_partner", 2, 16)
    bussiness_type_ = XLUtils.readData(file, "mass_partner", 2, 17)
    deployment_type_ = XLUtils.readData(file, "mass_partner", 2, 18)


    def __init__(self, driver):
        self.driver = driver



    def masspartnersearch(self):
        act = ActionChains(self.driver)
        sea = self.driver.find_element(By.XPATH, self.txt_parnter_search_xpath)
        act.move_to_element(sea).click().perform()
        self.driver.find_element(By.XPATH, self.parnter_mass_oem_xpath).click()
        time.sleep(5)

    def addnewvehicle(self):

        act = ActionChains(self.driver)
        time.sleep(5)
        addvec1 = self.driver.find_element(By.XPATH, self.add_new_vehicle_btn_xpath)
        act.move_to_element(addvec1).click().perform()
        time.sleep(5)
        dr = Select(self.driver.find_element(By.XPATH, self.cate_dropdown_form))
        dr.select_by_visible_text(self.Category_dropdown)
        dr1 = Select(self.driver.find_element(By.XPATH, self.vech_dropdown_form))
        dr1.select_by_visible_text(self.VehicleType_dropdown)
        self.driver.find_element(By.XPATH, self.vin_form).send_keys(self.vin)

        # dr3 = Select(self.driver.find_element(By.XPATH, self.master_doc_form))
        # dr3.select_by_visible_text("INSMOMAD0104G280210E")
        sideclick1 = self.driver.find_element(By.XPATH, self.side_click)
        act.move_to_element(sideclick1).click().perform()
        time.sleep(3)
        self.driver.find_element(By.XPATH, self.master_doc_form).send_keys(self.materdocid)
        self.driver.find_element(By.XPATH, self.master_doc_form).send_keys(Keys.ENTER)
        time.sleep(3)


        self.driver.find_element(By.XPATH, self.reg_num_form).send_keys(self.Registration_Number)
        time.sleep(2)
        self.driver.find_element(By.XPATH, self.drive_train_num_form).send_keys(self.Drive_train)
        dr2 = Select(self.driver.find_element(By.XPATH, self.vehicle_manu_dropdown))
        dr2.select_by_visible_text(self.Vehicle_Manufacturer_dropdown)

        self.driver.find_element(By.XPATH,self.manufacture_date ).send_keys(self.Manufacturing_Date_year)
        # mon = Select(self.driver.find_element(By.XPATH,self.mon_date))
        # mon.select_by_visible_text("Mar")
        # yer = Select(self.driver.find_element(By.XPATH,self.yer_date))
        # yer.select_by_visible_text("2018")
        # dates = self.driver.find_elements(By.XPATH,self.date_date)
        # for ele in dates:
        #     if ele.text == "14":
        #         ele.click()
        #         break
        dr3 = Select(self.driver.find_element(By.XPATH, self.state_dropdown))
        dr3.select_by_visible_text(self.state_dropdown_)
        dr4 = Select(self.driver.find_element(By.XPATH, self.zone_dropdown))
        time.sleep(5)
        dr4.select_by_visible_text(self.zone_dropdown_)
        time.sleep(5)
        sideclick2 = self.driver.find_element(By.XPATH, self.side_click_1)
        act.move_to_element(sideclick2).click().perform()
        time.sleep(5)

        self.driver.find_element(By.XPATH, self.bp_num_form).send_keys(self.bpid)
        time.sleep(18)
        self.driver.find_element(By.XPATH, self.bp_num_form).send_keys(Keys.ENTER)
        time.sleep(3)

        self.driver.find_element(By.XPATH, self.add_button_form).click()
        time.sleep(10)

    def searchvech(self):
            self.driver.find_element(By.XPATH, self.search_vec).send_keys(self.vin)
            self.driver.find_element(By.XPATH, self.search_vec_click).click()

    def linkvech(self):
            act = ActionChains(self.driver)
            time.sleep(2)
            self.driver.find_element(By.XPATH, self.maas_fleet_new_vechlink).click()
            sideclick = self.driver.find_element(By.XPATH, self.side_click)
            act.move_to_element(sideclick).click().perform()
            self.driver.find_element(By.XPATH, self.maas_fleet_operator_form).send_keys(self.maas_fleet_operator_)
            self.driver.find_element(By.XPATH, self.maas_fleet_operator_form).send_keys(Keys.ENTER)
            self.driver.find_element(By.XPATH, self.mass_fleet_operator_submit).click()
            time.sleep(5)

    def massfinance(self):
            time.sleep(3)
            act = ActionChains(self.driver)
            sea = self.driver.find_element(By.XPATH, self.txt_parnter_search_xpath)
            act.move_to_element(sea).click().perform()
            time.sleep(2)
            
            sea1 = self.driver.find_element(By.XPATH, self.finance_partner)
            act.move_to_element(sea1).click().perform()
            time.sleep(2)
            vechtab=self.driver.find_element(By.XPATH, self.vech_tab_xpath)
            act.move_to_element(vechtab).click().perform()
            vechtabsideclick = self.driver.find_element(By.XPATH, self.vech_tab_side_click)
            act.move_to_element(vechtabsideclick).click().perform()
            time.sleep(3)
            self.driver.find_element(By.XPATH, self.master_doc_form).send_keys(self.maas_fleet_operator_)
            self.driver.find_element(By.XPATH, self.master_doc_form).send_keys(Keys.ENTER)
    def paymentstatus(self):
            time.sleep(3)
            self.driver.find_element(By.XPATH, self.payment_status).click()
            self.driver.find_element(By.XPATH, self.deposite_amount_form).send_keys(self.deposite_amount)
            time.sleep(3)
            self.driver.find_element(By.XPATH, self.date_of_recpit_form).send_keys(self.amount_recepit)
            time.sleep(3)
            self.driver.find_element(By.XPATH, self.deposite_amount_submit_btn).click()
            time.sleep(10)

    def linkvechcustomer(self):
            self.driver.implicitly_wait(20)
            act = ActionChains(self.driver)
            sea = self.driver.find_element(By.XPATH, self.txt_parnter_search_xpath)
            act.move_to_element(sea).click().perform()
            self.driver.find_element(By.XPATH, self.mass_fleet_opeartor).click()
            self.driver.find_element(By.XPATH, self.vech_tab_xpath).click()
            self.driver.find_element(By.XPATH, self.search_vec).send_keys(self.vin)
            time.sleep(5)
            self.driver.find_element(By.XPATH, self.search_vec_click).click()
            time.sleep(3)
            sea4 = self.driver.find_element(By.XPATH, self.maas_fleet_new_vechlink)
            act.move_to_element(sea4).click().perform()
            time.sleep(3)
            sideclick = self.driver.find_element(By.XPATH, self.side_click)
            act.move_to_element(sideclick).click().perform()
            self.driver.find_element(By.XPATH, self.Mass_choose_cust_form).send_keys(self.customer_name_)
            self.driver.find_element(By.XPATH, self.Mass_choose_cust_form).send_keys(Keys.ENTER)
            side_click1 = self.driver.find_element(By.XPATH, self.side_click_1)
            act.move_to_element(side_click1).click().perform()
            self.driver.find_element(By.XPATH, self.choose_business_form).send_keys(self.bussiness_type_)
            self.driver.find_element(By.XPATH, self.choose_business_form).send_keys(Keys.ENTER)
            side_click2 = self.driver.find_element(By.XPATH, self.side_click_2)
            act.move_to_element(side_click2).click().perform()
            self.driver.find_element(By.XPATH, self.deployment_type_form).send_keys(self.deployment_type_)
            self.driver.find_element(By.XPATH, self.deployment_type_form).send_keys(Keys.ENTER)
            self.driver.find_element(By.XPATH,self.customer_submit_btn).click()
            time.sleep(10)










