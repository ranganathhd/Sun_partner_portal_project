from selenium.webdriver.common.by import By

class LoginPage():
    txt_email_xpath = "//input[@placeholder='Enter Email ID']"
    txt_password_xpath = "//input[@placeholder='Enter Password ']"
    btn_login_xpath = "//button[normalize-space()='LOGIN']"
    msg_myaccount_xpath = "//span[normalize-space()='Sun Mobility']"

    def __init__(self, driver):
        self.driver = driver

    def setEmail(self, email):
        self.driver.find_element(By.XPATH,self.txt_email_xpath).send_keys(email)

    def setPassword(self, pwd):
        self.driver.find_element(By.XPATH,self.txt_password_xpath).send_keys(pwd)

    def clickLogin(self):
        self.driver.find_element(By.XPATH,self.btn_login_xpath).click()

    def isMyAccountPageExists(self):
        # self.driver.implicitly_wait(10)
        try:
            return self.driver.find_element(By.XPATH,self.msg_myaccount_xpath).is_displayed()
        except:
            return False
        
