import time
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.remote import switch_to
from selenium.webdriver.support.select import Select
from Utilities import XLUtils
from selenium.webdriver.common.keys import Keys

class StationList():
    station_supply_partner="//a[normalize-space()='SUNMP00000069']"
    txt_parnter_search_xpath = "//input[@type='search']"
    add_station_btn="//button[normalize-space()='Add Station']"
    station_serialnum_form="//input[@id='StationSerialNumber']"
    station_service_location_drop="//select[@placeholder='Select Servicelocation']"
    station_type_drop="//select[@placeholder='Select Stationtype']"
    station_version_drop="//select[@placeholder='Select station version']"
    component_drop="(//select[@value='1'])[1]"
    component_serialnum="(//input[@placeholder='Enter Serial Number'])[1]"
    hardware_serial_num="(//input[@placeholder='Enter Serial Number'])[2]"
    model_drop="(//select[@value='1'])[3]"
    make_drop="(//select[@value='1'])[2]"
    add_more_btn="//span[normalize-space()='Add More']"
    component_drop2="(//select[@value='1'])[4]"
    component_serialnum2 ="(//input[@placeholder='Enter Serial Number'])[3]"
    hardware_serial_num2="(//input[@placeholder='Enter Serial Number'])[4]"
    make_drop2="(//select[@value='1'])[5]"
    model_drop2="(//select[@value='1'])[6]"
    addstation_submit_btn="//span[normalize-space()='Submit']"

    file = "C:\\Users\\ranganath.hd\\Sun1_project\\Sun_project\\Testdata\\test_data.xlsx"
    _station_serialnum_ = XLUtils.readData(file, "station_list", 2, 1)
    _station_type_drop = XLUtils.readData(file, "station_list", 2, 2)
    _station_version_drop= XLUtils.readData(file, "station_list", 2, 3)
    _component_drop = XLUtils.readData(file, "station_list", 2, 4)
    _component_serial_num = XLUtils.readData(file, "station_list", 2, 5)
    _hardware_serial_num = XLUtils.readData(file, "station_list", 2, 6)
    _component_drop2 = XLUtils.readData(file, "station_list", 2, 7)
    _component_serialnum2 = XLUtils.readData(file, "station_list", 2, 8)
    _hardware_serial_num2 = XLUtils.readData(file, "station_list", 2, 9)

    def __init__(self, driver):
        self.driver = driver

    def stationonboard(self):
        self.driver.implicitly_wait(10)
        act = ActionChains(self.driver)
        sea = self.driver.find_element(By.XPATH, self.txt_parnter_search_xpath)
        act.move_to_element(sea).click().perform()
        self.driver.find_element(By.XPATH, self.station_supply_partner).click()
        self.driver.find_element(By.XPATH, self.add_station_btn).click()
        self.driver.find_element(By.XPATH, self.station_serialnum_form).send_keys(self._station_serialnum_ )
        time.sleep(5)
        stationdrop1=Select(self.driver.find_element(By.XPATH, self.station_service_location_drop))
        stationdrop1.select_by_index(1)
        stationdrop2 = Select(self.driver.find_element(By.XPATH, self.station_type_drop))
        stationdrop2.select_by_visible_text(self._station_type_drop)
        stationdrop3 = Select(self.driver.find_element(By.XPATH, self.station_version_drop))
        stationdrop3.select_by_visible_text(self._station_version_drop)
        stationdrop4 = Select(self.driver.find_element(By.XPATH, self.component_drop))
        stationdrop4.select_by_visible_text(self._component_drop)
        self.driver.find_element(By.XPATH, self.component_serialnum).send_keys(self._component_serial_num )
        self.driver.find_element(By.XPATH, self.hardware_serial_num).send_keys(self._hardware_serial_num)
        # time.sleep(5)
        # stationdrop5=Select(self.driver.find_element(By.XPATH, self.make_drop))
        # stationdrop5.select_by_index(1)
        # stationdrop6 = Select(self.driver.find_element(By.XPATH, self.model_drop))
        # stationdrop6.select_by_index(1)
        time.sleep(2)
        statadd=self.driver.find_element(By.XPATH, self.add_more_btn)
        act.move_to_element(statadd).click().perform()
        time.sleep(2)
        stationdrop7 = Select(self.driver.find_element(By.XPATH, self.component_drop2))
        stationdrop7.select_by_visible_text(self._component_drop2 )
        self.driver.find_element(By.XPATH, self.component_serialnum2).send_keys(self._component_serialnum2)
        self.driver.find_element(By.XPATH, self.hardware_serial_num2).send_keys(self._hardware_serial_num2)
        # stationdrop8 = Select(self.driver.find_element(By.XPATH, self.make_drop2))
        # stationdrop8.select_by_index(1)
        # stationdrop9 = Select(self.driver.find_element(By.XPATH, self.model_drop2))
        # stationdrop9.select_by_index(1)
        self.driver.find_element(By.XPATH, self.addstation_submit_btn).click()
        time.sleep(10)

