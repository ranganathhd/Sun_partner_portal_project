# Script for Vehicle Onboarding by OEM [ Retail ] - test01
import time
from selenium.webdriver import ActionChains
import pytest

from Pageobjects.partner import ParnterPage
from Utilities.readProperties import ReadConfig
from Utilities.customLogger import LogGen
import os

class Test_Login():
    baseURL = ReadConfig.getApplicationURL()
    logger = LogGen.loggen()  # Logger

    user = ReadConfig.getUseremail()
    password = ReadConfig.getPassword()

    @pytest.mark.sanity
    def test_login(self,setup):

        self.logger.info("******* Starting test_002_login **********")
        self.driver = setup
        self.driver.get(self.baseURL)
        self.driver.implicitly_wait(20)
        self.driver.maximize_window()

        self.lp = ParnterPage(self.driver)
        self.lp.setEmail(self.user)
        self.lp.setPassword(self.password)
        self.lp.clickLogin()
        # time.sleep(7)
        self.lp.partner()
        self.lp.addoempartner()
