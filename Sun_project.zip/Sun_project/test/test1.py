import time

from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver import ActionChains

#from selenium.webdriver.edge.service import Service

serv_obj=Service("C:\\drivers\\chromedriver.exe")
driver=webdriver.Chrome(service=serv_obj)
driver.implicitly_wait(10)
act = ActionChains(driver)

driver.get("https://sm-partnerportal-stage.azurewebsites.net/")
driver.maximize_window()
driver.find_element(By.XPATH,"//input[@placeholder='Enter Email ID']").send_keys("sunmobilityadmin@sunmobility.co.in")
driver.find_element(By.XPATH,"//input[@placeholder='Enter Password ']").send_keys("Sunmob@123")
driver.find_element(By.XPATH,"//button[normalize-space()='LOGIN']").click()
driver.find_element(By.XPATH,"//a[@href='/home/partners']//span[@class='pcoded-micon ng-star-inserted']").click()
driver.find_element(By.XPATH,"//a[normalize-space()='SUNMP00000017']").click()
act.move_to_element(sea).click().perform()
time.sleep(5)

print("hi")